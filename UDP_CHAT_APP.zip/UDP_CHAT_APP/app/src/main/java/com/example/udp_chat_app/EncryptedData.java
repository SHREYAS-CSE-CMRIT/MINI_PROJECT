package com.example.udp_chat_app;

import android.os.StrictMode;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class EncryptedData {
    String status;

    EncryptedData(){
        ArrayList<HashMap<Character, Character>> allPossibilities=new ArrayList<>();
        HashMap< Character, Character> data =new HashMap<>();
        data.put('!','r');
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
//        File fs=new File("src/main/java/com/example/udp_chat_app/temp");
        URL oracle = null;
        try {
            oracle = new URL("https://www.w3.org/TR/PNG/iso_8859-1.txt");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(oracle.openStream()));
            StringBuilder stringBuilder=new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null){
                stringBuilder.append(inputLine);
                stringBuilder.append(System.lineSeparator());
            }

            in.close();

            status=stringBuilder.toString();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }







    }


}
