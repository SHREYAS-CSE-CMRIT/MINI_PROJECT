package com.example.udp_chat_app;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ServerActivity extends AppCompatActivity {

    public static String globStr;
    public  TextView textView,rep,iptext;
    Button send_btn;
    ImageButton imgBtn;
    private boolean end = false;
    EditText keyBoardValue;
    private SpeechRecognizer speechRecognizer;
    ProgressBar progressBar;
    final Handler handler = new Handler();
    public static String senderip,port;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    List<ModelClass > userList;
    Adapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);
        userList=new ArrayList<>();
        send_btn = findViewById(R.id.button);
        keyBoardValue=findViewById(R.id.EditTextView_ofKey);
        imgBtn= findViewById(R.id.button_mic);
        progressBar=findViewById(R.id.materialProgressBar);
        iptext=findViewById(R.id.serveripadd);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        senderip = getIntent().getStringExtra("ipaddress");
        port=getIntent().getStringExtra("ipport");
        iptext.setText("Messages are sent to "+senderip+ " I.P address");

        startServer(port);
        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
                keyBoardValue.setText(null);
            }
        });
        imgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                VoiceToText();
            }
        });
        Toast.makeText(getApplicationContext(), port, Toast.LENGTH_SHORT).show();
    }

    private void startServer(String port) {
        Thread thread = new Thread(new Runnable() {
            private String stringData = null;
            @Override
            public void run() {
                try {

                    DatagramSocket ds =new DatagramSocket(Integer.parseInt(port));
                    DatagramPacket dp;
                    while (!end) {
                        byte[] receive = new byte[20000];
                        dp= new DatagramPacket(receive,receive.length);
                        ds.receive(dp);
                        globStr= new String(receive);
                        String tempp=globStr;

                        updateUI(data(tempp.getBytes()));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

    private void sendMessage() {

        String msgg=keyBoardValue.getText().toString().trim();
        Thread msT=new MsgSender(msgg,senderip,port);
        msT.start();
        Toast.makeText(getApplicationContext(), "SENT", Toast.LENGTH_SHORT).show();
        DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss a");
        Date date=new Date();
        String time=dateFormat.format(date);
        initData1(msgg,"sent @ "+time);
        initRecycle();


    }

    public void VoiceToText(){
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(ServerActivity.this);
        final Intent speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle bundle) {
            }

            @SuppressLint("ResourceAsColor")
            @Override
            public void onBeginningOfSpeech() {

                keyBoardValue.setText("");
                keyBoardValue.setTextColor(R.color.black);
                keyBoardValue.setHintTextColor(R.color.teal_200);
                keyBoardValue.setHint("Listening...");
            }

            @Override
            public void onRmsChanged(float v) {
            }
            @Override
            public void onBufferReceived(byte[] bytes) {
            }
            @Override
            public void onEndOfSpeech() {
                keyBoardValue.setHint(" ");
            }
            @SuppressLint("ResourceType")
            @Override
            public void onError(int i) {
                keyBoardValue.setTextColor(R.color.design_default_color_error);
                keyBoardValue.setHint("Sorry Try Again");
                keyBoardValue.setTextColor(R.color.black);
                speechRecognizer.stopListening();
                speechRecognizer.destroy();
                progressBar.setVisibility(View.INVISIBLE);
            }
            @Override
            public void onResults(Bundle bundle) {
                ArrayList<String> data = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                keyBoardValue.setText(data.get(0));
                progressBar.setVisibility(View.INVISIBLE);
            }
            @Override
            public void onPartialResults(Bundle bundle) {
            }
            @Override
            public void onEvent(int i, Bundle bundle) {
            }
        });
        speechRecognizer.startListening(speechRecognizerIntent);
    }

    private void updateUI(StringBuilder stringData) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                String xx;
                if (stringData.length() != 0){
                    xx=stringData.toString();
                    DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss a");
                    Date date=new Date();
                    String time=dateFormat.format(date);
                    initData(xx,"recieved @ "+time);
                    initRecycle();
                }
            }
        });
    }

    public static StringBuilder data(byte[] a)
    {
        if (a == null)
            return null;
        StringBuilder retv = new StringBuilder();
        int i = 0;
        while (a[i] != 0)
        {
            retv.append((char) a[i]);
            i++;
        }
        return retv;

    }

    private void initRecycle() {
        recyclerView=findViewById(R.id.RecyclerViewa);
        layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new Adapter(userList);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        recyclerView.scrollToPosition(adapter.getItemCount()-1);
    }

    public void initData(String message,String time) {
        userList.add(new ModelClass(R.drawable.ic_baseline_people_24,message,time));
    }

    public void initData1(String message,String time) {
        userList.add(new ModelClass(R.drawable.ic_baseline_people_24green,message,time));
    }
}


