package com.example.udp_chat_app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<ModelClass> userList;

    public Adapter(List<ModelClass> userList){this.userList=userList;}



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.structure,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {    //used toi bind

        int imgresource=userList.get(position).getImageView();
        String message=userList.get(position).getText();
        String tttime=userList.get(position).getTime();

        holder.setData(imgresource,message,tttime);


    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{


        private ImageView image;
        private TextView text,time;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image=itemView.findViewById(R.id.imageView);
            text=itemView.findViewById(R.id.message);
            time=itemView.findViewById(R.id.time);


        }

        public void setData(int imgresource, String message, String tttime) {

            image.setImageResource(imgresource);
            text.setText(message);
            time.setText(tttime);
        }
    }
}
