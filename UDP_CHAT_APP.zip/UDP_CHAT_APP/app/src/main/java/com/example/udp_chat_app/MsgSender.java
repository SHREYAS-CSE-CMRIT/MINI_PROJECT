package com.example.udp_chat_app;
import android.util.Log;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class MsgSender extends Thread{
    String sendMsg,senderip,sdport;
    MsgSender( String msgg,String senderip,String port){
        this.sendMsg=msgg;
        this.senderip=senderip;
        this.sdport=port;
    }
    public void run() {
        try {
            byte buf[] = null;
            DatagramSocket ds = new DatagramSocket();
            String mms=sendMsg;
            buf=mms.getBytes();
            DatagramPacket DpSend =
                    new DatagramPacket(buf, buf.length, InetAddress.getByName(senderip), Integer.parseInt(sdport));
            ds.send(DpSend);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
