package com.example.udp_chat_app;

public class ModelClass {

    private int imageView;
    private String text;
    private String time;


    ModelClass(int imageView, String text, String time){
        this.imageView=imageView;
        this.text=text;
        this.time=time;
    }


    public int getImageView() {
        return imageView;
    }

    public String getText() {
        return text;
    }

    public String getTime() {
        return time;
    }


}
